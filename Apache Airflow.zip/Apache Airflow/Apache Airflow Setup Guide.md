Chào bạn! Với background **Java Backend Engineer đã thành thạo Docker** của bạn, tôi trả lời ngay câu hỏi này từ góc nhìn Data Engineering trong Production:

---

### MỚI BẮT ĐẦU NÊN DÙNG CÁCH NÀO?

> **Lựa chọn tối ưu nhất cho bạn: Dùng Docker Compose (Airflow official `docker-compose.yaml`).**

Tại sao không dùng Python Virtualenv (`pip install apache-airflow`)?

1. **Airflow không phải là một Python library đơn thuần.** Airflow là một **Hệ thống Phân tán (Distributed System)** gồm nhiều service độc lập:
* **Webserver:** UI để trigger & monitor DAGs.
* **Scheduler:** Trái tim của Airflow, phân tích DAG và lập lịch (cron/interval).
* **Triggerer:** Chạy các Deferred Tasks (async).
* **Metastore:** DB lưu trạng thái DAGs/Tasks (thường dùng Postgres, không nên dùng SQLite trong Production).
* **Executor/Worker:** Nơi chạy code task thực tế (Celery, Local, Kubernetes).


2. **Xung đột Dependencies:** Cài đặt Airflow trực tiếp qua `pip` rất dễ dính **dependency hell** (do Airflow đòi hỏi hàng trăm package với version rất khắt khe).
3. **Thói quen Production:** Trong môi trường doanh nghiệp, Airflow **100% được deploy bằng Docker / Kubernetes (Helm Chart)**. Việc setup Docker Compose ngay từ đầu giúp bạn nắm trọn kiến trúc multi-container của Airflow.

---

### BÀI TẬP 02: SETUP AIRFLOW LOCAL VỚI DOCKER COMPOSE

Để giúp bạn tiếp cận chuẩn chỉnh, chúng ta sẽ dựng một môi trường **Airflow Dev Env** gọn nhẹ trên Docker.

1. **Tạo Folder Project & Tải File Compose Official:** Tạo thư mục làm việc và tải file cấu hình từ Apache Airflow.
Tạo cấu trúc project trên máy local của bạn:

```bash
mkdir airflow-lab && cd airflow-lab
mkdir -p ./dags ./logs ./plugins ./config

# Tải file docker-compose.yaml chuẩn từ Apache Airflow (bản 2.x mới nhất)
curl -LfO 'https://airflow.apache.org/docs/apache-airflow/2.10.2/docker-compose.yaml'

```


2. **Cấu hình Môi trường & Phân quyền (.env):** Set AIRFLOW_UID để tránh lỗi permission trên Linux/macOS.
Tạo file `.env` cùng cấp với `docker-compose.yaml`:

```bash
echo "AIRFLOW_UID=$(id -u)" > .env

```

*Lưu ý cho Java Dev:* Trong file `docker-compose.yaml`, hãy chú ý service `postgres` (RDBMS làm Metastore) và `redis` (Message Broker nếu dùng CeleryExecutor).


3. **Khởi tạo Database & Chạy Cluster:** Chạy db init và up toàn bộ service.
Chạy lệnh khởi tạo cơ sở dữ liệu Airflow:

```bash
# Step 1: Init Database & Admin User
docker compose up airflow-init

# Step 2: Run all services in background
docker compose up -d

```

Kiểm tra trạng thái bằng `docker compose ps`. Tất cả các container (`airflow-webserver`, `airflow-scheduler`, `postgres`,...) phải ở trạng thái `healthy` hoặc `running`.


4. **Truy cập Airflow UI:** Port 8080 - Default Credentials.
Mở trình duyệt truy cập: `http://localhost:8080`

* **Username:** `airflow`
* **Password:** `airflow`


---

### YÊU CẦU BÀI TẬP (GỬI KẾT QUẢ CHO MENTOR)

Sau khi hoàn thành các bước trên, bạn hãy làm thử thách đầu tiên:

1. Tạo một file DAG Python tên là `01_first_dag.py` nằm trong folder `./dags/`.
2. Viết DAG với các tiêu chí chuẩn **Software Engineering**:
* Khai báo DAG bằng **TaskFlow API** (`@dag` và `@task` decorator) - đây là chuẩn viết Airflow modern nhất hiện nay, thay vì cách dùng Operator cổ điển.
* Thêm **Type Hints** đầy đủ cho Python functions.
* Gồm 3 task: `extract()` -> trả về dict data giả lập, `transform(data)` -> làm sạch/chuẩn hóa data, `load(data)` -> print log kết quả.
* Lập lịch: Chạy hằng ngày (`schedule="@daily"`), không chạy lại quá khứ (`catchup=False`).



Hãy thực hành setup và gửi snippet code file `01_first_dag.py` của bạn lên đây. Tôi sẽ review code chuẩn Senior Airflow Developer cho bạn!