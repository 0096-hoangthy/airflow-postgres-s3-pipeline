Trong các hệ thống Data Engineering thực tế ở doanh nghiệp, **XCom (Cross-Communication)** được ví như cơ chế truyền **Metadata / Lightweight State** giữa các Task độc lập trong một Pipeline.

Do đặc tính của Airflow là lưu toàn bộ giá trị XCom vào **Metastore Database (PostgreSQL/MySQL)**, các doanh nghiệp tuân thủ nghiêm ngặt quy tắc: **Chỉ dùng XCom cho dữ liệu dung lượng nhỏ (Thường là < 1KB - vài KB)**.

Dưới đây là 4 trường hợp thực tế nhất (Use Cases) mà các doanh nghiệp sử dụng XComs:

---

### 1. Truyền Tham Số Cấu Hình Động (Dynamic Runtime Metadata)

Trường hợp phổ biến nhất là Task trước quét/tạo ra các thông số môi trường hoặc đường dẫn, sau đó chuyển cho Task sau sử dụng:

* **Ví dụ 1 (S3 / Data Lake Path):** Task 1 (Extract) đẩy file dữ liệu lên S3 theo đường dẫn chứa UUID hoặc Timestamp ngẫu nhiên: `s3://my-bucket/raw/2026/10/25/data_uuid_9823.parquet`. Task 1 bắn đường dẫn file này qua XCom. Task 2 (Load into Snowflake/BigQuery) nhận đường dẫn từ XCom để thực thi câu lệnh `COPY INTO` hoặc `LOAD DATA`.
* **Ví dụ 2 (Database Partition / Offset):** Task 1 query log hệ thống để lấy `max_id` hoặc `latest_kafka_offset` hiện tại. Task 2 nhận giá trị offset này từ XCom để query tiếp từ mốc đó (Incremental Extract).

---

### 2. Lấy Job ID từ các External Compute Engine (Spark, Databricks, EMR, AWS Glue)

Trong các Enterprise Data Platform, Airflow chỉ đóng vai trò **Orchestrator** (điều phối execution), còn tính toán nặng sẽ đẩy qua cluster ngoài (Spark, Trino, EMR, Snowflake):

* **Kịch bản:**
1. Task 1 gửi API trigger một **Databricks Notebook Job** hoặc **AWS EMR Spark Job** và nhả về một `job_id` hoặc `run_id` (ví dụ: `databricks_job_12983`). Task 1 lưu `job_id` này vào XCom.
2. Task 2 (Sensor / Monitor) đọc `job_id` từ XCom để liên tục gửi API `GET /job/status/{job_id}` polling xem Spark Job đã hoàn thành hay chưa.
3. Task 3 (Notification) lấy status từ XCom để gửi alert qua Slack/Teams.



---

### 3. Dynamic Task Mapping (Sinh Task Động dựa trên Kết quả Task trước)

Airflow cho phép sinh ra $N$ task chạy song song dựa trên Output của Task trước nhờ sự kết hợp giữa **XCom** và phương thức `.expand()`:

* **Kịch bản:**
1. Task 1 (`get_active_tenants`) query Postgres lấy ra danh sách các khách hàng doanh nghiệp đang hoạt động: `["tenant_A", "tenant_B", "tenant_C"]`. Hàm `return` danh sách này (tự động đẩy vào XCom).
2. Task 2 (`process_tenant.expand()`) nhận danh sách từ XCom và tự động nhân bản thành 3 Task Instances riêng biệt chạy song song để xử lý dữ liệu cho từng Tenant.



---

### 4. Kiểm Tra Chất Lượng Dữ Liệu & Rẽ Nhánh Logic (Data Quality Check & Branching)

Dùng XCom kết hợp với `BranchPythonOperator` để quyết định luồng đi của Pipeline:

* **Kịch bản:**
1. Task 1 (Data Quality Check) đếm số lượng dòng bị lỗi null/duplicate trong file staging. `return {'null_count': 15, 'total_rows': 10000}`.
2. Task 2 (Branching Operator) đọc dict này từ XCom:
* Nếu `null_count / total_rows < 1%`: Rẽ nhánh sang Task `load_to_production`.
* Nếu `null_count / total_rows >= 1%`: Rẽ nhánh sang Task `quarantine_data` và gửi cảnh báo PagerDuty/Slack cho Data Quality Team.





---

### ⚠️ ANTI-PATTERNS: NHỮNG TRƯỜNG HỢP DOANH NGHIỆP CẤM DÙNG XCOM

Để đạt chuẩn Production, bạn cần tránh các sai lầm sau:

1. **CẤM truyền Pandas DataFrame / PySpark DataFrame qua XCom:** Việc ném dữ liệu bảng nghìn/triệu dòng vào XCom sẽ làm **phình to PostgreSQL Metastore** của Airflow, gây nghẽn RAM Scheduler và nghẽn Network IO.
* *Cách làm đúng:* Task 1 ghi DataFrame ra file `.parquet` trên S3/GCS/HDFS $\rightarrow$ Truyền **đường dẫn S3** qua XCom $\rightarrow$ Task 2 đọc Parquet từ S3.


2. **CẤM truyền Sensitive Data (API Secret Key, DB Password):** XCom lưu dữ liệu dưới dạng Plain Text/JSON trong DB. Mọi thông tin nhạy cảm bắt buộc phải dùng **Airflow Connections / Variables** hoặc **AWS Secrets Manager / Vault**.