Dưới đây là bản **Deep-Dive Concepts Study Guide** được mở rộng chi tiết từ sườn bài của bạn. Các khái niệm được phân tích theo tư duy **Software Engineering (Java OOP / System Architecture)** để giúp bạn nắm vững bản chất hoạt động bên dưới (under the hood) của Apache Airflow.

---

## 1. Workflow & DAGs

### Workflow

* **Bản chất:** Một quy trình xử lý dữ liệu gồm nhiều bước (Nodes) nối tiếp hoặc song song với nhau có phụ thuộc lẫn nhau (Dependencies).
* **Software Analogy:** Tương tự như một `Pipeline` hoặc `Chain of Responsibility` trong Java Design Patterns, nơi dữ liệu chảy qua từng bước xử lý.

### DAG (Directed Acyclic Graph)

Cấu trúc dữ liệu dạng đồ thị có hướng và **không lặp lại**:

* **Directed (Có hướng):** Task A $\rightarrow$ Task B. Quan hệ phụ thuộc được định nghĩa rõ ràng. Task B chỉ được chuyển sang trạng thái `READY` hoặc `QUEUED` khi Task A hoàn thành (`SUCCESS`).
* **Acyclic (Không chu trình):** **Tuyệt đối không có vòng lặp (No Loops)**. Task C không thể quay ngược lại Task A ($A \rightarrow B \rightarrow C \rightarrow A$ là cấm).
* *Tại sao lại cấm Acyclic trong Data Pipeline?* Vì nếu xuất hiện vòng lặp, Scheduler sẽ rơi vào **Infinite Loop (vòng lặp vô tận)**, không thể xác định được điểm kết thúc để đánh giá `DAG Run Status` hay tính toán điểm hạ nguồn (Downstream impact).


* **Tư duy thiết kế (How to loop?):** Nếu cần lặp qua dữ liệu (ví dụ: lặp qua 100 bảng để sync), Airflow sử dụng **Dynamic Task Mapping** (`.expand()`) để sinh ra 100 Task Instances chạy song song/nối tiếp riêng biệt, chứ không tạo vòng lặp trong đồ thị.

---

## 2. Tasks & Operators

### Operator (Class / Blueprint)

* **Bản chất:** Là một Python Class định nghĩa **CÁCH THỨC** thực thi công việc (`how to do`).
* **Kiến trúc:** Mọi Operator trong Airflow đều kế thừa từ base class `BaseOperator` và override phương thức `execute(context)`.
* **Phân loại Operator phổ biến:**
1. **Action Operators:** Thực thi logic hoặc câu lệnh (ví dụ: `PythonOperator`, `BashOperator`).
2. **Transfer Operators:** Di chuyển dữ liệu giữa các hệ thống (ví dụ: `S3ToRedshiftOperator`, `LocalFilesystemToGCSOperator`).
3. **Sensors:** Một dạng Operator đặc biệt chuyên "đứng chờ" một sự kiện xảy ra (ví dụ: `S3KeySensor` chờ file xuất hiện trên S3) trước khi cho phép task sau chạy.



### Task (Object / Instance Config)

* **Bản chất:** Là một Node cụ thể trong đồ thị DAG.
* **Mối quan hệ với Operator:**

$$\text{Task} = \text{Operator}(\text{Configuration Parameters})$$


* **Ví dụ Java OOP:**
```python
# Operator = Class PostgresOperator
# Task = Instance của PostgresOperator với các tham số cấu hình cụ thể
extract_user_task = PostgresOperator(
    task_id="extract_user_data",
    postgres_conn_id="production_db",
    sql="SELECT * FROM users WHERE updated_at = '{{ ds }}'"
)

```



### Xu hướng hiện đại: TaskFlow API (`@task` decorator)

Ở Airflow 2.x trở lên (và Airflow 3), thay vì khai báo `PythonOperator` cồng kềnh, cộng đồng chuyển sang dùng **TaskFlow API**. Hàm Python thuần được annotate bởi `@task` sẽ tự động chuyển thành một Task Node, giúp truyền dữ liệu giữa các task (dùng XCom bên dưới) như các hàm Python/Java thông thường.

---

## 3. Execution & Instances

Đây là phần dễ gây nhầm lẫn nhất giữa môi trường Dev và Production.

### Execution Date / Logical Date

* **Bản chất:** Là mốc thời gian đại diện cho **LÔ DỮ LIỆU (Data Partition)** cần được xử lý, **KHÔNG PHẢI** là thời gian thực tế (Wall-clock time) máy tính bấm nút chạy task.
* **Cơ chế Scheduling Window (Khái niệm Interval):**
* Nếu DAG chạy daily với `schedule="@daily"` cho ngày `2026-10-18`.
* `Execution Date` sẽ là: `2026-10-18 00:00:00`.
* Thời điểm thực tế Scheduler trigger DAG chạy là: `2026-10-19 00:00:00` (khi khoảng thời gian của ngày 18 trôi qua trọn vẹn để đảm bảo đủ dữ liệu).



### DAG Run

* **Công thức:** $\text{DAG Run} = \text{DAG Blueprint} + \text{Execution Date}$
* **Bản chất:** Đại diện cho 1 bản ghi (record) trong bảng `dag_run` thuộc Metastore Database (PostgreSQL). Nó theo dõi toàn bộ trạng thái của một lần chạy workflow (State: `running`, `success`, `failed`).

### Task Instance (TI)

* **Công thức:** $\text{Task Instance} = \text{Task Node} + \text{Execution Date}$
* **Bản chất:** Đại diện cho 1 bản ghi trong bảng `task_instance` của Database.
* **Vòng đời trạng thái (Life Cycle State):**

$$\text{No Status} \rightarrow \text{Scheduled} \rightarrow \text{Queued} \rightarrow \text{Running} \rightarrow \text{Success / Failed / Up\_for\_retry}$$


* **Tính chất quan trọng:** Nếu 1 Task trong DAG Run bị lỗi (`Failed`), bạn chỉ cần **Clear** duy nhất `Task Instance` đó trên UI. Airflow sẽ rerun lại đúng Task Instance này mà không cần chạy lại toàn bộ DAG từ đầu.

---

## 4. Active Retrieval & Check Your Understanding (Giải Đáp Bài Tập)

### Q1: Tính chất "Acyclic" (Không chu trình) ảnh hưởng thế nào đến cách thiết kế Task?

* **Đáp:** Bạn không thể dùng tư duy lặp lại `while(condition)` hoặc `do-while` trực tiếp giữa các Task Node.
* **Giải pháp:**
1. Xử lý vòng lặp **bên trong** một Task (ví dụ: vòng lặp `for` bên trong Python code của `PythonOperator`).
2. Nếu muốn sinh thêm Task động theo số lượng record/file, sử dụng **Dynamic Task Mapping** (`.expand()`).
3. Nếu muốn chạy lại workflow khi gặp dữ liệu xấu, phải thiết kế theo dạng **Retry Mechanism** của Task hoặc chia nhỏ thành 2 DAGs riêng biệt trigger lẫn nhau.



### Q2: Muốn chạy một truy vấn SQL, chọn Operator hay Task để định nghĩa Logic? Cái nào dùng để định nghĩa Scheduling?

* **Đáp:**
* **Định nghĩa Logic:** Dùng **Operator** (cụ thể là `SQLExecuteQueryOperator` hoặc `PostgresOperator`).
* **Định nghĩa Scheduling:** **KHÔNG DÙNG** Operator hay Task! Scheduling (như `schedule="0 2 * * *"` hoặc `@daily`) được định nghĩa ở cấp độ toàn cục của **DAG** (`with DAG(...)` hoặc `@dag()`). Mọi Task trong cùng một DAG sẽ thừa hưởng chung một lịch trình thực thi đó.



### Q3: DAG Run khác gì với một Task Instance?

* **Đáp:**
* **DAG Run** quản lý **vĩ mô (Macro level)**: Nó đại diện cho trạng thái tổng thể của toàn bộ Pipeline cho một mốc `Execution Date`.
* **Task Instance** quản lý **vi mô (Micro level)**: Phân rã nhỏ nhất của từng nút bấm xử lý cụ thể. Một `DAG Run` chứa nhiều `Task Instance` có mối quan hệ cha-con.
* **Ví dụ:** Tương tự như trong Java Spring Batch: `DAG Run` tương đương với `JobExecution`, còn `Task Instance` tương đương với `StepExecution`.



---

## 5. Quick Tips Cho Senior Engineer Mindset

1. **Idempotency (Tính bất biến):** Viết code cho Task sao cho cho dù `Task Instance` chạy lại 10 lần cho cùng 1 `Execution Date` thì kết quả lưu vào Data Warehouse vẫn giống hệt nhau (Dùng `OVERWRITE` partition thay vì `INSERT INTO`).
2. **Stateless Tasks:** Các Task nên là các hàm không lưu trạng thái (Stateless). Không dùng biến toàn cục để truyền dữ liệu dung lượng lớn giữa các task. Dùng **XCom** cho metadata nhỏ (< 1KB) hoặc lưu dữ liệu intermediate ra S3/Database.
3. **Decoupling Logic:** DAG file `.py` chỉ làm nhiệm vụ **Orchestration** (điều phối). Logic xử lý tính toán nặng nên đẩy sang Spark, Trino, DBT hoặc Docker Container (`KubernetesPodOperator`). DAG file nên cực kỳ ngắn gọn và nhẹ nhàng.