Giao diện mới này thuộc thế hệ UI hiện đại của **Apache Airflow 3**. So với phiên bản 2.x, giao diện đã được thiết kế lại hoàn toàn theo phong cách Dashboard tập trung, trực quan và hiện đại hơn rất nhiều.

Tổng quan cấu trúc UI mới của bạn gồm các khu vực quan trọng sau:

---

### 1. Thanh Navigation Dọc (Left Sidebar Navigation)

Thanh menu chính đã chuyển từ **phía trên cùng sang bên trái**:

* **Home:** Trang Dashboard tổng quan hiện tại (Welcome screen).


* **Dags:** Danh sách toàn bộ các DAGs (tương tự trang chủ cũ của bản 2.x).


* **Assets (thay thế cho Datasets):** Quản lý các Data-aware scheduling/Assets dependencies.


* **Browse:** Xem audit log, lịch sử DAG Runs, Task Instances chi tiết.


* **Admin:** Quản lý Connections (Data Sources), Variables, Pools, Configs.


* **Security:** Phân quyền User / Roles / Access Control.



---

### 2. Khu Vực System Health & Metrics (Phần Trên Dashboard)

* **Stats (Failed Dags / Running Dags / Active Dags):** Báo cáo nhanh số lượng DAG đang chạy, đang bật hoặc bị lỗi trong hệ thống.


* **Health Check:** Hiển thị thời gian thực (Real-time) trạng thái hoạt động của 4 thành phần cốt lõi:


* **MetaDatabase:** Kết nối PostgreSQL/MySQL Metastore.


* **Scheduler:** Bộ lập lịch chính của Airflow.


* **Triggerer:** Xử lý Asynchronous / Deferred tasks.


* **Dag Processor:** Tiến trình parse file python DAG trong thư mục `./dags`.
(Tất cả đang hiển thị tích xanh `✓` nghĩa là cluster của bạn hoàn toàn khỏe mạnh).




* **Pool Slots (`128`):** Quản lý giới hạn số lượng task chạy đồng thời trong hệ thống để tránh nghẽn tài nguyên (Concurrency limit).



---

### 3. Khu Vực Thống Kê & Lịch Sử (History & Events)

* **Dag Runs (Queued / Running / Success / Failed):** Biểu đồ tỷ lệ (%) các lần thực thi pipeline theo khoảng thời gian bạn chọn (mặc định 24h gần nhất).


* **Asset Events (bên phải):** Lịch sử ghi nhận các sự kiện dữ liệu được cập nhật (Data-driven triggering).



---

### Mẹo Thao Tác Cho Bạn Ngay Bây Giờ

Để xem lại danh sách các DAGs giống như giao diện 2.x trước đó:

1. Click vào icon **Dags** (icon sơ đồ cây ở thanh menu dọc bên trái).


2. Nút Bật/Tắt (Toggle), thông tin Schedule, và lịch sử chạy của từng DAG sẽ nằm trọn trong tab **Dags** này.



Tất cả dịch vụ nền tảng đã **Healthy** 100%. Bạn hoàn toàn có thể chuyển qua tab **Dags** để theo dõi file `01_first_dag.py` khi bạn thả code vào thư mục làm việc!