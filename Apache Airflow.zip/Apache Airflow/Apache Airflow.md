**Apache Airflow** là một nền tảng mã nguồn mở hàng đầu dùng để **lập trình, đặt lịch và giám sát các quy trình xử lý dữ liệu (Data Pipelines / Workflows)** dưới dạng mã nguồn Python (**Workflow-as-Code**).

Airflow đóng vai trò như một **"Nhạc trưởng" (Orchestrator)** trong hệ sinh thái Data Engineering. Nó không trực tiếp xử lý dữ liệu nặng mà chịu trách nhiệm ra lệnh cho các hệ thống khác (như PySpark, SQL Database, AWS Glue, Snowflake) chạy đúng thứ tự, đúng thời điểm và xử lý khi có lỗi xảy ra.

---

### 1. Các khái niệm cốt lõi (Core Concepts)

Để làm chủ Airflow, bạn chỉ cần nắm vững 6 khái niệm chính sau:

* **DAG (Directed Acyclic Graph):**
* Đồ thị có hướng không chu trình. Đây là nơi bạn định nghĩa toàn bộ luồng công việc.
* Một DAG tập hợp các **Task** và các mối quan hệ phụ thuộc giữa chúng (ví dụ: `Task A (Extract) >> Task B (Transform) >> Task C (Load)`).


* **Operator:**
* Là mẫu dựng sẵn (Template) cho một Task. Airflow cung cấp hàng trăm Operator tích hợp sẵn:
* `PythonOperator`: Chạy một hàm Python thuần.
* `BashOperator`: Chạy lệnh Script / Terminal.
* `PostgresOperator` / `MySqlOperator`: Thực thi các câu lệnh SQL.
* `SparkSubmitOperator`: Gửi job lên Spark Cluster.

* **Task & Task Instance:**
* **Task:** Là một nút (Node) trong DAG (được khởi tạo từ Operator).
* **Task Instance:** Là trạng thái thực thi cụ thể của Task đó tại một mốc thời gian chỉ định (ví dụ: Task *Clean_Data* chạy lúc 08:00 AM ngày 17/10).

* **Sensor:**
* Một loại Operator đặc biệt đóng vai trò "chờ đợi" một sự kiện bên ngoài xảy ra rồi mới cho luồng chạy tiếp (ví dụ: chờ đến khi có file mới tải lên AWS S3, hoặc chờ API trả về HTTP 200).


* **Hooks:**
* Lớp trừu tượng (Abstraction Layer) quản lý việc kết nối bảo mật tới các hệ thống bên ngoài (PostgreSQL, MySQL, AWS S3, Slack...).
* *Tương đương Backend:* Giống như `DataSource` / JDBC Connection Pool trong Java.


* **XCom (Cross-Communication):**
* Cơ chế cho phép các Task truyền các mẩu dữ liệu nhỏ (Metadata) cho nhau (ví dụ: Task A truyền `file_path` cho Task B).
* *Lưu ý:* XCom lưu trong Metadata DB nên tuyệt đối **không dùng để truyền Dataset lớn**.



---

### 2. Kiến trúc hệ thống (System Architecture)

Khi bạn triển khai Airflow (qua Docker hoặc Kubernetes), hệ thống gồm 5 thành phần chính:

```
                  +-------------------+
                  |   Webserver (UI)  |
                  +---------+---------+
                            |
+------------------+  +-----+-----+  +--------------------+
|  DAG Directory   |->| Scheduler |->| Execution Engine   |
|  (Python Files)  |  +-----+-----+  | (Executor/Worker)  |
+------------------+        |        +--------------------+
                            v
                  +-------------------+
                  |    Metadata DB    |
                  | (PostgreSQL/MySQL)|
                  +-------------------+

```

1. **Scheduler (Trái tim của Airflow):**
* Phân tích các file DAG, lập lịch các Task Instance và đẩy chúng vào Queue để chuẩn bị chạy.


2. **Webserver (Giao diện người dùng - UI):**
* Ứng dụng Flask cung cấp UI trực quan để bật/tắt DAG, theo dõi trạng thái xanh/đỏ của Task, xem Log, bấm chạy lại (Retry) và quản lý biến môi trường.


3. **Metadata Database:**
* Lưu trữ toàn bộ trạng thái của DAGs, Task Instances, Variable, Connections, lịch sử chạy (thường dùng PostgreSQL hoặc MySQL).


4. **Executor:**
* Quyết định *cách thức* các Task sẽ được thực thi.
* *LocalExecutor:* Chạy đa tiến trình (Multiprocessing) trên cùng 1 máy (dùng cho Dev/Local).
* *CeleryExecutor / KubernetesExecutor:* Phân tán Task ra hàng chục Worker node khác nhau (dùng cho Production).


5. **Workers:**
* Nơi thực sự chạy mã nguồn của các Task.

![[Pasted image 20261025104947.png]]



---

### 3. So sánh: Airflow vs. Cronjob / Quartz Scheduler / Spring Batch

| Tiêu chí                                   | Cronjob / Linux Cron                         | Spring Batch / Quartz         | Apache Airflow                                                    |
| ------------------------------------------ | -------------------------------------------- | ----------------------------- | ----------------------------------------------------------------- |
| **Phụ thuộc (Dependencies)**               | Rất khó cấu hình Task A xong mới chạy Task B | Làm tốt trong nội bộ app Java | Quản lý phụ thuộc cực mạnh giữa nhiều hệ thống dị thể             |
| **Giao diện (UI & Observability)**         | Không có (Phải xem file log thủ công)        | Phải tự dựng dashboard        | Có Web UI cực kỳ mạnh mẽ, theo dõi visual linh hoạt               |
| **Khả năng Retry / Alerting**              | Phải tự viết script bắt lỗi                  | Code bằng Java logic          | Hỗ trợ cấu hình `retries`, `retry_delay`, báo lỗi qua Slack/Email |
| **Backfilling (Chạy lại dữ liệu quá khứ)** | Cực kỳ phức tạp                              | Phải viết code bù             | Tự động chạy bù dữ liệu quá khứ chỉ với 1 câu lệnh                |

---

### 4. Ba "Quy tắc vàng" của Senior Data Engineer khi dùng Airflow

1. **Airflow là Orchestrator, KHÔNG PHẢI Data Processor:**
* Tránh dùng `PythonOperator` để nạp 10GB data vào Pandas DataFrame rồi biến đổi trực tiếp trên Airflow Worker. Hãy để Airflow gọi Spark, Snowflake hoặc SQL DB làm việc đó.


2. **Tính chất Idempotency (Tính vô hiệu đối với lặp lại):**
* Một Task khi chạy lại $N$ lần cho cùng một khoảng thời gian phải cho ra **cùng một kết quả duy nhất** (không bị nhân đôi dữ liệu trong DB).


3. **DAG File phải "Sạch" (Top-level code restraint):**
* Không viết lệnh truy vấn DB hoặc gọi API trực tiếp ở cấp độ khai báo file DAG. Scheduler quét các file DAG mỗi vài giây một lần; nếu viết code nặng ở ngoài hàm task, Scheduler sẽ bị nghẽn làm sập hệ thống.