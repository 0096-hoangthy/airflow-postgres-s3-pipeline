Trong Apache Airflow, **Sensor** là một dạng Task đặc biệt ( kế thừa từ `BaseSensorOperator`) được thiết kế với mục đích duy nhất: **Chờ đợi một điều kiện hoặc sự kiện cụ thể xảy ra trước khi cho phép các Task phía sau thực thi**.

Nếu các Operator thông thường (như `PythonOperator`, `BashOperator`) bấm chạy là thực hiện logic ngay lập tức, thì Sensor sẽ liên tục **kiểm tra (poll)** trạng thái của một hệ thống bên ngoài cho đến khi điều kiện trả về `True` (hoặc bị Timeout).

---

### 1. NGUYÊN LÝ HOẠT ĐỘNG VÀ CÁC THAM SỐ CỐT LÕI

Khi một Sensor được kích hoạt, nó sẽ gọi phương thức `poke()` theo chu kỳ thời gian được cấu hình:

* **`poke_interval` (thời gian nghỉ giữa các lần check):** Khoảng thời gian (tính bằng giây) mà Sensor tạm dừng trước khi kiểm tra lại điều kiện (mặc định thường là 60 giây).
* **`timeout` (thời gian chờ tối đa):** Sau khoảng thời gian này nếu điều kiện vẫn chưa thỏa mãn, Sensor sẽ bị coi là thất bại (`Failed`) để tránh treo pipeline vĩnh viễn.
* **`mode` (cơ chế quản lý tài nguyên Worker):** Đây là tham số **quan trọng nhất** cần lưu ý:
* `mode='poke'` (Mặc định): Task giữ nguyên Worker slot và liên tục chiếm dụng RAM/CPU trong suốt quá trình chờ. **Không nên dùng nếu phải chờ lâu**.
* `mode='reschedule'`: Nếu chưa đạt điều kiện, Task sẽ **nhả Worker slot ra** cho các job khác chạy, sau đó tự xếp lịch kiểm tra lại sau khoảng `poke_interval`. **Khuyên dùng cho các task chờ lâu (> 5 phút)**.



---

### 2. CÁC TÌNH HUỐNG THỰC TẾ SỬ DỤNG SENSOR TRONG DOANH NGHIỆP

1. **Chờ File Xuất Hiện Trên Storage (`FileSensor`, `S3KeySensor`, `GCSObjectsWithPrefixSensor`):**
* *Kịch bản:* Pipeline cần xử lý dữ liệu từ đối tác đẩy lên S3 vào khoảng 6:00 - 7:00 sáng. Dùng `S3KeySensor` để theo dõi thư mục S3, ngay khi file `daily_report_20261027.csv` xuất hiện thì mới trigger task ETL tiếp theo.


2. **Chờ Dữ Liệu Hoặc Bảng Trong Database (`SqlSensor`):**
* *Kịch bản:* Kiểm tra xem bảng `raw_orders` đã nạp đủ số lượng bản ghi của ngày hôm nay chưa (`SELECT COUNT(*) FROM raw_orders WHERE date = current_date > 10000`) rồi mới tiến hành chạy tổng hợp doanh thu.


3. **Chờ Một DAG Phía Ngoài Hoàn Thành (`ExternalTaskSensor`):**
* *Kịch bản:* DAG Báo cáo Doanh thu (DAG B) chỉ được phép chạy sau khi DAG Nạp Dữ liệu Khách hàng (DAG A) hoàn tất thành công.


4. **Chờ API/HTTP Endpoint Trả Về Kết Quả (`HttpSensor`):**
* *Kịch bản:* Gửi yêu cầu export dữ liệu sang một hệ thống bên thứ ba, dùng `HttpSensor` để poll kiểm tra trạng thái HTTP 200 / `status: COMPLETED`.



---

### 3. CÁCH VIẾT SENSOR TRONG TASKFLOW API (`@task.sensor`)

Từ Airflow 2.4+ và chuẩn trên Airflow 3.x, bạn có thể viết Sensor rất ngắn gọn bằng decorator `@task.sensor`:

```python
from datetime import datetime, timedelta
from airflow.decorators import dag, task

@dag(
    dag_id='demo_sensor_pipeline',
    start_date=datetime(2026, 1, 1),
    schedule='@daily',
    catchup=False
)
def sensor_pipeline():

    @task.sensor(poke_interval=30, timeout=3600, mode='reschedule')
    def wait_for_data_flag() -> bool:
        """Kiểm tra điều kiện: Trả về True để pass, False để tiếp tục chờ."""
        # Giả lập logic kiểm tra file/database/API
        import random
        is_ready = random.choice([True, False])
        print(f"Checking data readiness... Result: {is_ready}")
        return is_ready

    @task
    def process_data():
        print("[PROD LOG] Data is ready! Starting ETL process...")

    # Task process_data chỉ chạy khi wait_for_data_flag trả về True
    wait_for_data_flag() >> process_data()

sensor_pipeline()

```

---

### 💡 SENIOR BEST PRACTICES KHI DÙNG SENSOR

* **Luôn đặt `mode='reschedule'**` cho các Sensor dự kiến phải chờ trên 5 phút để tránh làm cạn kiệt Worker Pools của Airflow Cluster.
* **Luôn set `timeout` hợp lý** để hệ thống bắn alert (Slack/PagerDuty) khi dữ liệu nguồn bị trễ quá lâu so với SLA.
* **Tận dụng Airflow Deferrable Operators (Triggerer):** Trong Airflow 2.2+, các Deferrable Sensors (dùng công nghệ `asyncio`) giúp tiết kiệm tài nguyên tối đa so với Sensor truyền thống.