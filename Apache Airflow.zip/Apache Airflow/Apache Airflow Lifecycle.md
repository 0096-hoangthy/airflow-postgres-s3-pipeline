Dựa vào hình ảnh **Task Lifecycle** mà bạn cung cấp, dưới đây là bảng ghi chú chi tiết từng trạng thái (State) trong vòng đời thực thi của một Task Instance trong Apache Airflow. Bảng được phân loại theo từng giai đoạn và thành phần quản lý (Scheduler, Executor, Worker) để bạn dễ tra cứu và nắm bắt bản chất hệ thống:

  

### BẢNG GHI CHÚ TASK LIFECYCLE IN APACHE AIRFLOW

|**Trạng thái (State)**|**Thành phần quản lý**|**Ý nghĩa & Bản chất kỹ thuật**|**Hành động tiếp theo / Điều kiện chuyển trạng thái**|
|---|---|---|---|
|**No status**|Initial State|Task Instance mới được tạo ra trong Metastore Database nhưng chưa được Scheduler xử lý.|Chuyển sang **Scheduler** để phân tích dependencies.|
|**Scheduled**|**Scheduler**|Scheduler đã kiểm tra và xác nhận các điều kiện phụ thuộc (Upstream Tasks) đã thỏa mãn. Task đã sẵn sàng để gửi tới Executor.|Chuyển sang **Executor**.|
|**Removed**|**Scheduler**|Task đã bị xóa khỏi file code DAG trong quá trình DAG đang chạy hoặc được chỉnh sửa.|Dừng thực thi (Terminal State).|
|**Upstream Failed**|**Scheduler**|Một hoặc nhiều Task phía trước (Upstream Task) bị `Failed` hoặc gặp sự cố, khiến Task hiện tại không đủ điều kiện chạy.|Dừng thực thi (Terminal State).|
|**Skipped**|**Scheduler**|Task bị bỏ qua do logic phân nhánh (Branching / `BranchPythonOperator`) hoặc do điều kiện `trigger_rule` quy định.|Bỏ qua Task, cho phép Downstream Task xử lý tiếp.|
|**Queued**|**Executor**|Executor đã nhận Task và đưa vào hàng chờ (Queue - ví dụ: Celery/RabbitMQ, Redis hoặc Kubernetes Queue) chờ Worker trống slot để nhặt công việc.|Chuyển sang **Worker** khi có tài nguyên khả dụng.|
|**Running**|**Worker**|Task Instance đang thực sự chạy code (execute) trên một Worker Node cụ thể.|Chuyển sang `Success`, `Failed`, `Shutdown`, hoặc `Up for reschedule` tùy thuộc vào kết quả chạy code.|
|**Success**|**Worker**|Task thực thi thành công không có lỗi (Exit Code 0).|Kết thúc thành công (Terminal State). Trigger các Downstream Tasks.|
|**Failed**|**Worker**|Code trong Task bắn ra Exception/Error hoặc bị Timeout trong quá trình thực thi.|Nếu còn lượt retry $\rightarrow$ Chuyển sang `Up for retry`. Nếu hết lượt $\rightarrow$ Kết thúc thất bại (Terminal State).|
|**Shutdown**|**Worker**|Task bị can thiệp dừng đột ngột do yêu cầu từ hệ thống, do người dùng hủy tay (Kill), hoặc Worker bị gỡ bỏ.|Dừng thực thi (Terminal State).|
|**Up for retry**|**Worker / Scheduler**|Task bị `Failed` nhưng vẫn còn số lần thử lại (retries > 0). Airflow sẽ chờ khoảng thời gian `retry_delay` trước khi đẩy lại về Scheduler.|Quay lại trạng thái **Scheduled** để chạy lại.|
|**Up for reschedule**|**Worker / Scheduler**|Dành riêng cho **Sensor** khi hoạt động ở chế độ `mode='reschedule'`. Trong lúc chờ điều kiện thỏa mãn, Task nhả lại Worker slot để tránh lãng phí tài nguyên hệ thống.|Khi hết thời gian `poke_interval`, Scheduler sẽ đưa Task quay lại trạng thái **Scheduled**.|

### MẸO TƯ DUY CHO SENIOR DATA ENGINEER:

1. **3 Trạng thái chờ trung gian quan trọng:**
    
      
    - **`Scheduled`**: Đã qua ải **Scheduler** (đủ điều kiện logic).
        
          
        
    - **`Queued`**: Đã qua ải **Executor** (đang đứng trong hàng đợi).
        
          
        
    - **`Running`**: Đã qua ải **Worker** (máy chủ vật lý/container đang vắt óc tính toán code).
        
          
        
2. **Tối ưu tài nguyên với Sensor (`Up for reschedule` vs `Up for retry`):**
    
      
    - Phân biệt rõ: **`Up for retry`** xảy ra khi **có lỗi** (Exception), còn **`Up for reschedule`** xảy ra khi **chờ dữ liệu** (Sensor Mode) để tối ưu tài nguyên RAM/CPU cho cluster.


![[Pasted image 20261025105058.png]]