**Backfill** trong Apache Airflow là quá trình **chạy bù (hoặc chạy lại)** các `DAG Runs` cho các khoảng thời gian trong **quá khứ (Historical Data Intervals)** mà pipeline chưa xử lý hoặc cần xử lý lại.

---

### 1. Bản Chất Kỹ Thuật Của Backfill

Thông thường, Airflow Scheduler tự động kích hoạt DAG Run theo thời gian thực (Wall-clock time). Tuy nhiên, khi bạn kích hoạt Backfill:

* Airflow sẽ bỏ qua thời điểm hiện tại và ép hệ thống tạo ra một chuỗi các `DAG Runs` cho khoảng mốc `Logical Date` (Execution Date) trong quá khứ.
* Mỗi `DAG Run` trong quá khứ sẽ nhận đúng mốc `Data Interval` của ngày/giờ tương ứng. Điều này giúp các macro thời gian (như `{{ ds }}` hay `data_interval_start`) trong code SQL/Python tự động lấy đúng dữ liệu của ngày quá khứ đó.

---

### 2. Các Tình Huống Sử Dụng Backfill Trong Doanh Nghiệp

Trong các hệ thống Data Platform thực tế, Backfill là tính năng cực kỳ quan trọng được sử dụng trong 4 tình huống chính:

#### 1. Onboarding Pipeline Mới (Khởi tạo dữ liệu lịch sử)

Khi bạn vừa phát triển xong một DAG mới (ví dụ: DAG tính toán chỉ số LTV của khách hàng) và deploy lên Production vào tháng 10/2026. Tuy nhiên, Ban Giám đốc muốn xem báo cáo LTV này cho cả **toàn bộ năm 2025 và từ đầu năm 2026 đến nay**.

* **Giải pháp:** Bạn dùng Backfill để "chạy ngược" DAG này cho từng ngày từ `2025-01-01` đến `2026-10-24` nhằm sinh ra toàn bộ dữ liệu lịch sử trong Data Warehouse.

#### 2. Sửa Bug Logic Code (Bug Fix & Re-processing)

Phát hiện ra một hàm tính toán doanh thu trong Task `transform` bị viết sai logic trong 2 tuần qua (từ ngày 10/10 đến 24/10/2026), dẫn đến dữ liệu trong bảng Production bị sai lệch.

* **Giải pháp:**
1. Fix bug trong source code và deploy phiên bản DAG mới.
2. Dùng Backfill chạy lại đúng khoảng thời gian từ `2026-10-10` đến `2026-10-24`. Vì code được thiết kế theo chuẩn **Idempotent** (ghi đè partition), dữ liệu cũ bị sai sẽ được thay thế hoàn toàn bằng dữ liệu chuẩn mới.



#### 3. Khôi Phục Sau Sự Cố Hạ Tầng (Recovery After Outage)

Hệ thống Nguồn (Source Database / API) bị sập hoặc gặp sự cố mạng trong 3 ngày cuối tuần khiến Airflow không thể cào dữ liệu về được.

* **Giải pháp:** Sau khi bên hạ tầng khắc phục xong sự cố, Data Engineer kích hoạt Backfill cho 3 ngày bị thiếu để bù đắp dữ liệu hổng trong Data Lake.

#### 4. Thay Đổi Schema Bảng Hoặc Thêm Field Mới (Schema Evolution)

Data Warehouse bổ sung thêm một trường dữ liệu mới (ví dụ: thêm cột `device_type` vào bảng `fact_orders`).

* **Giải pháp:** Chạy Backfill lại toàn bộ lịch sử để populate giá trị cho cột `device_type` mới này trên tất cả các partition cũ.

---

### 3. Hai Cách Thực Hiện Backfill Trong Airflow

#### Cách 1: Qua giao diện Airflow 3 UI (UI Backfill Tab)

Airflow 3 đã hỗ trợ giao diện quản lý Backfill rất trực quan:

1. Vào chi tiết DAG $\rightarrow$ Chọn tab **Backfills**.
2. Nhấn **Create Backfill** $\rightarrow$ Chọn khoảng ngày bắt đầu (`From`) và kết thúc (`To`).
3. Chọn cơ chế (ví dụ: `Reverse` chạy lùi hoặc `Forward` chạy tiến) rồi bấm **Submit**.

#### Cách 2: Qua CLI Command (Khuyên dùng cho Volume lớn)

Chạy lệnh trực tiếp trên terminal của Airflow Worker/Scheduler Container:

```bash
airflow dags backfill \
    --start-date 2026-01-01 \
    --end-date 2026-01-31 \
    --clear-at-sequencing \
    my_production_dag

```

---

### ⚠️ SENIOR BEST PRACTICES KHI CHẠY BACKFILL

1. **Luôn bật `catchup=False` mặc định:** Trong file DAG, luôn khai báo `catchup=False`. Khi nào thực sự cần bù dữ liệu, hãy chủ động kích hoạt Backfill qua UI/CLI cho một khoảng ngày cụ thể, tránh việc vừa bật DAG lên Airflow đã tự động trigger hàng ngàn runs làm nghẽn Database Metastore.
2. **Kiểm soát Concurrency (`max_active_runs`):** Khi backfill khoảng thời gian dài (ví dụ: 3 năm = 1095 ngày), nếu không giới hạn, Airflow có thể sinh ra 1000 task cùng lúc đánh sập Database nguồn/đích. Hãy giới hạn tham số `max_active_runs=3` hoặc `max_active_tasks` trong DAG.
3. **Đảm bảo tính Bất Biến (Idempotency):** Code trong Task phải đảm bảo khi chạy backfill nhiều lần cho cùng 1 ngày, kết quả cuối cùng trong Database vẫn giống nhau (sử dụng `TRUNCATE PARTITION` + `INSERT` thay vì `INSERT` thuần).