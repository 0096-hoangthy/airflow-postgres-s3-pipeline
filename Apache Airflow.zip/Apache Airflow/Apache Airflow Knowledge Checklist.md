Dưới đây là bảng tổng hợp lộ trình kiến thức và các khái niệm cốt lõi trong **Apache Airflow** được phân cấp từ mức độ **Fresher** (Hiểu và vận hành cơ bản) đến **Middle Data Engineer** (Thiết kế hệ thống, tối ưu hiệu năng và vận hành Production).

---

### Bảng tổng hợp kiến thức Apache Airflow (Fresher $\rightarrow$ Middle DE)

| Cấp độ | Nhóm kiến thức | Khái niệm / Keyword cốt lõi | Mô tả & Mục tiêu ứng dụng thực tế |
| --- | --- | --- | --- |
| **Fresher** | **1. Core Concepts** | **DAG (Directed Acyclic Graph)** | Đồ thị luồng công việc không chu trình. Biết cách định nghĩa `dag_id`, `schedule_interval`, `start_date`, `catchup=False`. |
|  |  | **Operators** | Các mẫu dựng sẵn cho Task: `BashOperator`, `PythonOperator`, `PostgresOperator`/`MySqlOperator`. |
|  |  | **Task & Task Instance** | Phân biệt Task (định nghĩa trong code) và Task Instance (một phiên chạy cụ thể của Task tại 1 mốc thời gian `execution_date`). |
|  | **2. Task Control** | **Task Dependencies** | Thiết lập thứ tự chạy giữa các Task dùng toán tử `>>`, `<<` hoặc `set_upstream()`, `set_downstream()`. |
|  |  | **XComs (Cross-Communication)** | Cơ chế truyền dữ liệu nhỏ (Metadata, biến trạng thái) giữa các Task. Nắm quy tắc: **Không truyền Dataset lớn qua XCom**. |
|  |  | **Variables & Connections** | Quản lý biến môi trường và thông số kết nối DB/API an toàn trên Web UI thay vì ghi cứng (hardcode) trong code. |
|  | **3. Basic Operation** | **Airflow Web UI** | Thao tác thành thạo trên UI: Bật/Tắt DAG, bấm Trigger, xem Grid/Graph View, đọc Log debug khi Task báo lỗi (Red status). |
|  |  | **Task Lifecycle & States** | Nắm rõ các trạng thái của Task: `success`, `failed`, `queued`, `running`, `up_for_retry`, `skipped`. |
| --- | --- | --- | --- |
| **Junior** | **4. Advanced Operators** | **Sensors** | Sử dụng `FileSensor`, `S3KeySensor`, `ExternalTaskSensor` để bắt sự kiện (chờ file xuất hiện, chờ DAG khác chạy xong). |
|  |  | **Branching** | Sử dụng `BranchPythonOperator` để rẽ nhánh luồng chạy dựa trên điều kiện logic (IF/ELSE). |
|  |  | **TaskFlow API** | Cú pháp viết DAG hiện đại dạng `@dag` và `@task` decorator trong Python 3 (giúp code gọn và tự động xử lý XCom). |
|  | **5. Architecture & Backfill** | **System Architecture** | Nắm vững vai trò và cơ chế tương tác giữa 5 thành phần: **Webserver, Scheduler, Metadata DB, Executor, Worker**. |
|  |  | **Catchup & Backfilling** | Hiểu cơ chế `catchup=True/False` và cách dùng lệnh CLI `airflow dags backfill` để chạy bù dữ liệu quá khứ. |
|  |  | **Templating with Jinja** | Sử dụng các biến Macro có sẵn của Airflow như `{{ ds }}`, `{{ ds_add(...) }}` để xử lý dữ liệu động theo ngày. |
| --- | --- | --- | --- |
| **Middle** | **6. Performance & Scale** | **Executors** | Phân biệt và cấu hình các loại Executor: `LocalExecutor` (Đa tiến trình), `CeleryExecutor` (Distributed Queue), `KubernetesExecutor` (Pod per task). |
|  |  | **Dynamic DAGs** | Viết code sinh DAG tự động từ file cấu hình (JSON/YAML) hoặc database thay vì tạo từng file thủ công. |
|  |  | **Concurrency Control** | Tối ưu tài nguyên hệ thống qua cấu hình: `max_active_runs`, `task_concurrency`, `pools` (giới hạn số kết nối đồng thời vào DB). |
|  | **7. Production Best Practices** | **Top-Level Code Restraint** | Tránh viết logic nặng (gọi API, query DB) bên ngoài hàm task để không làm nghẽn vòng lặp quét file của **Scheduler**. |
|  |  | **Idempotency** | Thiết kế Task đảm bảo tính chất **Idempotent**: Chạy lại $N$ lần cho cùng một ngày chỉ ra duy nhất 1 kết quả (không duplicate data). |
|  |  | **Custom Operators & Hooks** | Tự viết Custom Operator / Custom Hook khi cần kết nối với hệ thống nội bộ của doanh nghiệp mà Airflow chưa hỗ trợ. |
|  | **8. Monitoring & CI/CD** | **Alerting & SLA** | Cấu hình tự động gửi cảnh báo qua Slack/Email (`on_failure_callback`) và thiết lập SLA (`sla_miss_callback`) khi Task chạy quá giờ. |
|  |  | **Docker & Deployment** | Tự tay viết `docker-compose.yml` để dựng môi trường Dev local và viết CI/CD Pipeline (GitHub Actions) để deploy DAGs tự động lên Production. |

---

### Chiến lược tích lũy từ Bảng Kiến Thức

* **Giai đoạn 1 (Fresher - Tuần này):** Dựng Docker Airflow local, tập trung code thành thạo các khái niệm ở mục **1, 2, 3**. Viết được DAG ETL cơ bản: Rút data $\rightarrow$ Clean $\rightarrow$ Lưu DB.
* **Giai đoạn 2 (Junior - 1-2 tháng tới):** Áp dụng TaskFlow API, dùng Sensors để chờ dữ liệu, xử lý rẽ nhánh (Branching) và tập chạy Backfill dữ liệu quá khứ.
* **Giai đoạn 3 (Middle - Dự án thực tế):** Đưa script PySpark/dbt vào làm Task trong Airflow, tối ưu Pools, viết Custom Callbacks báo lỗi qua Slack và đóng gói bài bản qua Docker/CI-CD.